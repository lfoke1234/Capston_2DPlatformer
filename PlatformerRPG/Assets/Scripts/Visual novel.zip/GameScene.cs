using UnityEngine;

namespace RPG.VisualNovel
{
    public class GameScene : ScriptableObject { }
}